# BDS Core 7.0 — C++20

First quality-oriented DSP baseline.

- PCM test rate: 48 kHz, mono synthetic tones
- OSR: 16x (768 kHz internal rate)
- Kaiser-windowed sinc interpolation and reconstruction
- Second-order ternary error-feedback modulator carried over from v4.1
- Radix-3 packing: five ternary symbols per byte
- Polyphase interpolation and FIR decimation
- SNR, RMSE, peak error, and single-tone gain measurements

Build:
```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
./build/bds_quality_test
```

Important: this is a DSP experiment, not yet a complete `.bds` codec. The FIR cutoff,
tap count, and modulator must be validated with swept-frequency, THD+N, in-band
noise PSD, aliasing, stereo, and real-music tests. No Android/JNI or WAV I/O yet.
