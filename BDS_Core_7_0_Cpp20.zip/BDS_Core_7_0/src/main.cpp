#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <numbers>
#include <stdexcept>
#include <vector>

namespace {
constexpr int FS = 48000, OSR = 16, TAPS = 2049;
constexpr double PI = std::numbers::pi_v<double>;

double i0(double x) {
    double sum = 1.0, term = 1.0, y = x*x/4.0;
    for (int k=1; k<80; ++k) {
        term *= y/(double(k)*k); sum += term;
        if (term < sum*1e-15) break;
    }
    return sum;
}

std::vector<double> lowpass(int taps, double cutoff, double beta, double gain) {
    if (taps < 3 || !(taps&1) || cutoff <= 0 || cutoff >= .5)
        throw std::invalid_argument("Invalid FIR design parameters");
    int mid=taps/2; double den=i0(beta), sum=0;
    std::vector<double> h(taps);
    for (int n=0;n<taps;++n) {
        int x=n-mid;
        double sinc=x==0 ? 2*cutoff : std::sin(2*PI*cutoff*x)/(PI*x);
        double r=double(x)/mid;
        double w=i0(beta*std::sqrt(std::max(0.0,1-r*r)))/den;
        h[n]=sinc*w; sum+=h[n];
    }
    for (double& v:h) v=v/sum*gain;
    return h;
}

// Polyphase interpolation: h has DC gain OSR; zero extension at boundaries.
std::vector<double> interpolate(const std::vector<double>& x,
                                const std::vector<double>& h) {
    std::vector<double> y(x.size()*OSR,0.0);
    const int mid=int(h.size()/2), nt=int(h.size());
    for (std::size_t n=0;n<y.size();++n) {
        double acc=0;
        long long k0=std::max<long long>(0,
            (long long)std::ceil((double((long long)n-(nt-1-mid)))/OSR));
        long long k1=std::min<long long>((long long)x.size()-1,
            (long long)std::floor((double((long long)n+mid))/OSR));
        for(long long k=k0;k<=k1;++k) {
            long long hi=(long long)n-k*OSR+mid;
            if(hi>=0 && hi<nt) acc+=x[(size_t)k]*h[(size_t)hi];
        }
        y[n]=acc;
    }
    return y;
}

std::vector<int8_t> modulate(const std::vector<double>& x,double& max_state) {
    std::vector<int8_t> s; s.reserve(x.size());
    double e1=0,e2=0; max_state=0;
    for(double sample:x) {
        double v=sample+2*e1-e2;
        max_state=std::max(max_state,std::abs(v));
        int8_t q=v>.5?1:(v<-.5?-1:0);
        double e=v-q; e2=e1; e1=e; s.push_back(q);
    }
    return s;
}

std::vector<uint8_t> pack3(const std::vector<int8_t>& s) {
    std::vector<uint8_t> out; out.reserve((s.size()+4)/5);
    for(size_t i=0;i<s.size();i+=5) {
        unsigned v=0,m=1;
        for(size_t j=0;j<5;++j) {
            int8_t q=i+j<s.size()?s[i+j]:0;
            unsigned d=q==-1?0u:(q==0?1u:(q==1?2u:3u));
            if(d==3) throw std::invalid_argument("Invalid ternary symbol");
            v+=d*m; m*=3;
        }
        if(v>242) throw std::runtime_error("Invalid radix-3 byte");
        out.push_back((uint8_t)v);
    }
    return out;
}

std::vector<int8_t> unpack3(const std::vector<uint8_t>& bytes,size_t count) {
    std::vector<int8_t> out; out.reserve(bytes.size()*5);
    for(uint8_t b:bytes) {
        if(b>242) throw std::invalid_argument("Invalid radix-3 byte");
        unsigned v=b;
        for(int j=0;j<5;++j) {
            unsigned d=v%3; v/=3;
            out.push_back(d==0?-1:(d==1?0:1));
        }
    }
    if(count>out.size()) throw std::runtime_error("Truncated radix-3 data");
    out.resize(count); return out;
}

std::vector<double> decimate(const std::vector<int8_t>& s,
                             const std::vector<double>& h) {
    if(s.size()%OSR) throw std::invalid_argument("Symbol count not divisible by OSR");
    std::vector<double> y(s.size()/OSR);
    int mid=int(h.size()/2), nt=int(h.size());
    for(size_t m=0;m<y.size();++m) {
        long long center=(long long)m*OSR; double acc=0;
        for(int j=0;j<nt;++j) {
            long long ix=std::clamp(center+j-mid,0LL,(long long)s.size()-1);
            acc+=double(s[(size_t)ix])*h[(size_t)j];
        }
        y[m]=acc;
    }
    return y;
}

void report(const std::vector<double>& x,const std::vector<double>& y,
            double f,int margin) {
    if(x.size()!=y.size()) throw std::runtime_error("Length mismatch");
    double ps=0,pn=0,peak=0, xs=0,xc=0,ys=0,yc=0;
    int end=int(x.size())-margin, count=end-margin;
    for(int n=margin;n<end;++n) {
        double e=x[n]-y[n], a=2*PI*f*n/FS;
        ps+=x[n]*x[n]; pn+=e*e; peak=std::max(peak,std::abs(e));
        xs+=x[n]*std::sin(a); xc+=x[n]*std::cos(a);
        ys+=y[n]*std::sin(a); yc+=y[n]*std::cos(a);
    }
    double snr=pn>1e-30?10*std::log10(ps/pn):INFINITY;
    double rmse=std::sqrt(pn/count);
    double gain=20*std::log10(std::hypot(ys,yc)/std::hypot(xs,xc));
    std::cout<<std::fixed<<std::setprecision(3)
      <<"Tone "<<f<<" Hz | SNR "<<snr<<" dB | RMSE "<<rmse
      <<" | Peak "<<peak<<" | Gain "<<gain<<" dB\n";
}

std::vector<double> sine(double f) {
    std::vector<double> x(FS);
    for(int n=0;n<FS;++n) x[n]=.5*std::sin(2*PI*f*n/FS);
    return x;
}
}

int main() {
    try {
        constexpr double cutoff_hz=22000.0, beta=8.6;
        double fc=cutoff_hz/(FS*OSR);
        auto hi=lowpass(TAPS,fc,beta,OSR);
        auto lo=lowpass(TAPS,fc,beta,1.0);
        std::cout<<"BDS Core 7.0 C++20 | 48 kHz | OSR "<<OSR
                 <<" | internal "<<FS*OSR<<" Hz\n";
        std::cout<<"Initial Kaiser FIR: "<<TAPS<<" taps, cutoff "
                 <<cutoff_hz<<" Hz (provisional)\n";
        for(double f:{1000.0,10000.0,20000.0}) {
            auto x=sine(f), up=interpolate(x,hi);
            double state=0; auto sym=modulate(up,state);
            auto bytes=pack3(sym);
            auto restored=unpack3(bytes,sym.size());
            if(restored!=sym) throw std::runtime_error("Radix-3 round-trip failed");
            auto y=decimate(restored,lo);
            std::cout<<"  symbols="<<sym.size()<<" packed_bytes="<<bytes.size()
                     <<" max_quantizer_input="<<state<<"\n";
            report(x,y,f,TAPS/(2*OSR)+4);
        }
        std::cout<<"Radix-3 round-trip and sample-count checks passed.\n";
        std::cout<<"Synthetic mono baseline only; not a production codec yet.\n";
    } catch(const std::exception& e) {
        std::cerr<<"ERROR: "<<e.what()<<"\n"; return 1;
    }
}
