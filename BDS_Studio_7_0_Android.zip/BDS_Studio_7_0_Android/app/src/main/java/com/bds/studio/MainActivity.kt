package com.bds.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

private data class AudioTrackItem(
    val uri: Uri,
    val title: String,
    val artist: String,
    val mime: String
)

private data class UserPlaylist(val name: String, val trackUris: MutableList<String> = mutableListOf())

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var screenHost: FrameLayout
    private lateinit var miniHost: LinearLayout
    private lateinit var navHost: LinearLayout
    private var appFont: Typeface? = null

    private val preferences by lazy { getSharedPreferences("bds_preferences", MODE_PRIVATE) }
    private val tracks = mutableListOf<AudioTrackItem>()
    private val playlists = mutableListOf<UserPlaylist>()
    private var activePlaylistName: String? = null
    private val bdsFiles = mutableListOf<Uri>()
    private var currentIndex = -1
    private var mediaPlayer: MediaPlayer? = null
    private var playerPrepared = false
    private var currentLyrics = listOf<LyricLine>()
    private var lyricTextView: TextView? = null
    private var lyricsScrollView: ScrollView? = null
    private var lastActiveLyricIndex = -2
    private var lyricLineViews = mutableListOf<TextView>()
    private var playerProgress: SeekBar? = null
    private var playerTime: TextView? = null
    private var playerFormat: TextView? = null
    private var isUpdatingProgress = false
    private var currentPage = "collection"
    private var searchQuery = ""
    private var currentAccent = Color.rgb(240, 68, 68)
    private var currentBg = Color.rgb(8, 8, 8)
    private var currentPanel = Color.rgb(28, 28, 30)
    private var currentText = Color.WHITE
    private var currentMuted = Color.LTGRAY
    private var themeName = "midnight"
    private var fontStyle = "hywenhei"
    private var artworkMode = "original"

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            val player = mediaPlayer
            if (playerPrepared && player != null) {
                try {
                    val position = player.currentPosition
                    val duration = player.duration.coerceAtLeast(1)
                    isUpdatingProgress = true
                    playerProgress?.max = duration
                    playerProgress?.progress = position.coerceAtMost(duration)
                    playerTime?.text = "${formatTime(position)}   ·   -${formatTime((duration - position).coerceAtLeast(0))}"
                    isUpdatingProgress = false
                    updateActiveLyric(position.toLong())
                } catch (_: IllegalStateException) {
                    isUpdatingProgress = false
                }
            }
            progressHandler.postDelayed(this, 450L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        try {
            appFont = Typeface.createFromAsset(assets, "fonts/hywenhei-85w.ttf")
        } catch (_: Exception) {
            appFont = Typeface.DEFAULT_BOLD
        }
        applySavedTheme()
        loadPlaylists()
        buildShell()
        showCollection()
        loadSavedLibrary()
        progressHandler.post(progressRunnable)
    }

    private fun applySavedTheme() {
        themeName = preferences.getString("theme", "midnight") ?: "midnight"
        fontStyle = preferences.getString("font_style", "hywenhei") ?: "hywenhei"
        artworkMode = preferences.getString("artwork_mode", "original") ?: "original"
        currentAccent = try {
            Color.parseColor(preferences.getString("accent", "#F04444") ?: "#F04444")
        } catch (_: Exception) {
            Color.rgb(240, 68, 68)
        }
        when (themeName) {
            "light" -> {
                currentBg = Color.rgb(238, 238, 238)
                currentPanel = Color.WHITE
                currentText = Color.rgb(24, 24, 24)
                currentMuted = Color.DKGRAY
                window.statusBarColor = Color.rgb(238, 238, 238)
                window.navigationBarColor = Color.rgb(238, 238, 238)
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            "monochrome" -> {
                currentBg = Color.rgb(12, 12, 12)
                currentPanel = Color.rgb(38, 38, 38)
                currentText = Color.WHITE
                currentMuted = Color.LTGRAY
                window.statusBarColor = Color.BLACK
                window.navigationBarColor = Color.BLACK
                window.decorView.systemUiVisibility = 0
            }
            else -> {
                currentBg = Color.rgb(8, 8, 8)
                currentPanel = Color.rgb(28, 28, 30)
                currentText = Color.WHITE
                currentMuted = Color.LTGRAY
                window.statusBarColor = Color.BLACK
                window.navigationBarColor = Color.BLACK
                window.decorView.systemUiVisibility = 0
            }
        }
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentBg)
        }
        screenHost = FrameLayout(this)
        root.addView(screenHost, LinearLayout.LayoutParams(-1, 0, 1f))
        miniHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(miniHost, LinearLayout.LayoutParams(-1, -2))
        navHost = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(7), dp(8), dp(8))
            background = rounded(currentPanel, 28)
        }
        root.addView(navHost, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(dp(12), dp(5), dp(12), dp(8))
        })
        setContentView(root)
        refreshBottomAreas()
    }

    private fun refreshBottomAreas() {
        if (!::miniHost.isInitialized || !::navHost.isInitialized) return
        miniHost.removeAllViews()
        val item = currentTrackOrNull()
        if (item != null && currentPage != "player" && currentPage != "lyrics") {
            val mini = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(currentPanel, 22)
                setOnClickListener { showPlayer() }
            }
            val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            textColumn.addView(label(item.title, 15f, currentText, true, 1), LinearLayout.LayoutParams(-1, -2))
            textColumn.addView(label(item.artist, 12f, currentMuted), LinearLayout.LayoutParams(-1, -2))
            mini.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
            mini.addView(actionText(if (isPlaying()) "Ⅱ" else "▶", 23f, currentAccent) {
                togglePlayback()
                refreshBottomAreas()
            }, LinearLayout.LayoutParams(dp(48), dp(42)))
            miniHost.addView(mini, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(dp(14), dp(4), dp(14), dp(2))
            })
        }
        navHost.visibility = if (currentPage == "player" || currentPage == "lyrics") View.GONE else View.VISIBLE
        navHost.removeAllViews()
        val tabs = listOf("home" to "⌂\nBeranda", "collection" to "▣\nKoleksi", "repo" to "▦\nRepo", "search" to "⌕\nTelusuri")
        tabs.forEach { (page, caption) ->
            val active = currentPage == page
            val tab = label(caption, 12f, if (active) currentAccent else currentText, active, 1).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(5), dp(8), dp(5))
                setOnClickListener { when (page) {
                    "home" -> showHome()
                    "collection" -> showCollection()
                    "repo" -> showRepo()
                    "search" -> showSearch()
                } }
            }
            navHost.addView(tab, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
    }

    private fun render(page: String, view: View) {
        currentPage = page
        screenHost.removeAllViews()
        screenHost.addView(view, FrameLayout.LayoutParams(-1, -1))
        refreshBottomAreas()
    }

    private fun pageColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(currentBg)
        setPadding(dp(20), dp(18), dp(20), dp(12))
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        addView(content, ScrollView.LayoutParams(-1, -2))
    }

    private fun label(text: String, size: Float, color: Int = currentText, heavy: Boolean = false, maxLines: Int = Int.MAX_VALUE): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = if (heavy) {
                when (fontStyle) {
                    "serif" -> Typeface.create("serif", Typeface.BOLD)
                    "sans" -> Typeface.create("sans-serif", Typeface.BOLD)
                    else -> appFont ?: Typeface.DEFAULT_BOLD
                }
            } else Typeface.create("sans-serif", Typeface.NORMAL)
            this.maxLines = maxLines
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun actionText(text: String, size: Float = 15f, color: Int = currentAccent, action: () -> Unit): TextView {
        return label(text, size, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(currentPanel, 18)
            setOnClickListener { action() }
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun addGap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun showHome() {
        val page = pageColumn()
        page.addView(label("BDS STUDIO", 27f, currentText, true))
        page.addView(label("AUDIO ENGINEERING & MUSIC PLAYER", 10f, currentMuted, true))
        addGap(page, 22)
        page.addView(label("Selamat datang", 23f, currentText, true))
        page.addView(label("Pemutar musik dan ruang eksperimen codec BDS.", 14f, currentMuted))
        addGap(page, 20)
        page.addView(actionText("＋  Tambah musik", 15f) { pickAudioFiles() }, LinearLayout.LayoutParams(-1, -2))
        addGap(page, 10)
        page.addView(actionText("Buka Audio Lab", 15f) { showAudioLab() }, LinearLayout.LayoutParams(-1, -2))
        addGap(page, 9)
        page.addView(actionText("Pengaturan tampilan", 15f) { showSettings() }, LinearLayout.LayoutParams(-1, -2))
        addGap(page, 22)
        page.addView(label("Terakhir diputar", 19f, currentText, true))
        val item = currentTrackOrNull()
        page.addView(label(item?.let { "${it.title}\n${it.artist}" } ?: "Belum ada lagu yang diputar.", 14f, currentMuted))
        render("home", scroll(page))
    }

    private fun loadSavedLibrary() {
        val raw = preferences.getString("library_uris", "[]") ?: "[]"
        if (raw == "[]") return
        thread(name = "bds-library-restore") {
            val restored = mutableListOf<AudioTrackItem>()
            try {
                val array = org.json.JSONArray(raw)
                for (index in 0 until array.length()) {
                    val value = array.optString(index)
                    if (value.isBlank()) continue
                    val uri = Uri.parse(value)
                    try { restored += readTrack(uri) } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
            runOnUiThread {
                restored.forEach { item -> if (tracks.none { it.uri == item.uri }) tracks += item }
                if (restored.isNotEmpty() && currentPage == "collection") showCollection()
            }
        }
    }

    private fun saveLibraryUris() {
        val array = org.json.JSONArray()
        tracks.forEach { array.put(it.uri.toString()) }
        preferences.edit().putString("library_uris", array.toString()).apply()
    }

    private fun loadPlaylists() {
        playlists.clear()
        val raw = preferences.getString("playlists", "[]") ?: "[]"
        try {
            val array = org.json.JSONArray(raw)
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val name = item.optString("name").trim()
                if (name.isBlank()) continue
                val uris = mutableListOf<String>()
                val values = item.optJSONArray("uris") ?: org.json.JSONArray()
                for (i in 0 until values.length()) values.optString(i).takeIf { it.isNotBlank() }?.let { uris += it }
                playlists += UserPlaylist(name, uris)
            }
        } catch (_: Exception) {
            playlists.clear()
        }
    }

    private fun savePlaylists() {
        val array = org.json.JSONArray()
        playlists.forEach { playlist ->
            val item = org.json.JSONObject()
            item.put("name", playlist.name)
            val uris = org.json.JSONArray()
            playlist.trackUris.forEach { uris.put(it) }
            item.put("uris", uris)
            array.put(item)
        }
        preferences.edit().putString("playlists", array.toString()).apply()
    }

    private fun showCreatePlaylistDialog() {
        val field = EditText(this).apply {
            hint = "Nama playlist"
            setSingleLine(true)
            setTextColor(currentText)
            setHintTextColor(currentMuted)
        }
        AlertDialog.Builder(this)
            .setTitle("Buat playlist")
            .setView(field)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Buat") { _, _ ->
                val name = field.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, "Nama playlist tidak boleh kosong.", Toast.LENGTH_SHORT).show()
                } else if (playlists.any { it.name.equals(name, ignoreCase = true) }) {
                    Toast.makeText(this, "Nama playlist sudah digunakan.", Toast.LENGTH_SHORT).show()
                } else {
                    playlists += UserPlaylist(name)
                    savePlaylists()
                    activePlaylistName = null
                    showCollection()
                }
            }
            .show()
    }

    private fun showAddTrackToPlaylistDialog(trackIndex: Int) {
        if (playlists.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("Buat playlist terlebih dahulu, lalu tahan lagu untuk menambahkannya.")
                .setNegativeButton("Tutup", null)
                .setPositiveButton("Buat playlist") { _, _ -> showCreatePlaylistDialog() }
                .show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tambahkan ke playlist")
            .setItems(names) { _, which ->
                val uri = tracks.getOrNull(trackIndex)?.uri?.toString() ?: return@setItems
                val playlist = playlists[which]
                if (uri !in playlist.trackUris) playlist.trackUris += uri
                savePlaylists()
                Toast.makeText(this, "Ditambahkan ke ${playlist.name}", Toast.LENGTH_SHORT).show()
                if (activePlaylistName == playlist.name) showCollection()
            }
            .show()
    }

    private fun showRepo() {
        val page = pageColumn()
        page.addView(label("Repo", 28f, currentText, true))
        page.addView(label("Kelola berkas BDS lokal.", 13f, currentMuted))
        addGap(page, 18)
        page.addView(actionText("＋  Tambah file BDS", 15f) { pickBdsFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        addGap(page, 16)
        page.addView(label("${bdsFiles.size} file BDS", 15f, currentMuted, true))
        if (bdsFiles.isEmpty()) {
            addGap(page, 22)
            page.addView(label("Belum ada file BDS.\n\nCatatan: core saat ini sudah memiliki primitive Radix-3 dan quantizer eksperimental. Pembaca container serta encoder/decoder file BDS lengkap masih dalam pengembangan.", 14f, currentMuted))
        } else {
            bdsFiles.forEach { uri ->
                page.addView(actionText(displayName(uri) ?: uri.lastPathSegment ?: "File BDS", 14f, currentText) {
                    Toast.makeText(this, "Container BDS belum dapat didekode pada build ini.", Toast.LENGTH_LONG).show()
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
            }
        }
        render("repo", scroll(page))
    }

    private fun showSearch() {
        val page = pageColumn()
        page.addView(label("Telusuri", 28f, currentText, true))
        page.addView(label("Cari lagu dalam koleksi lokal.", 13f, currentMuted))
        addGap(page, 16)
        val field = EditText(this).apply {
            hint = "Judul lagu atau artis"
            setHintTextColor(currentMuted)
            setTextColor(currentText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(currentPanel, 24)
            setText(searchQuery)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchQuery = s?.toString().orEmpty()
                    rebuildSearchRows()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        page.addView(field, LinearLayout.LayoutParams(-1, dp(52)))
        addGap(page, 14)
        searchRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(searchRows, LinearLayout.LayoutParams(-1, -2))
        rebuildSearchRows()
        render("search", scroll(page))
    }

    private lateinit var searchRows: LinearLayout

    private fun rebuildSearchRows() {
        if (!::searchRows.isInitialized) return
        searchRows.removeAllViews()
        val q = searchQuery.trim().lowercase(Locale.ROOT)
        val matches = tracks.withIndex().filter { (_, item) ->
            q.isEmpty() || item.title.lowercase(Locale.ROOT).contains(q) || item.artist.lowercase(Locale.ROOT).contains(q)
        }
        if (matches.isEmpty()) {
            searchRows.addView(label("Tidak ada hasil. Tambahkan audio dari halaman Koleksi.", 13f, currentMuted))
        }
        matches.forEach { indexed ->
            val item = indexed.value
            searchRows.addView(actionText("♫   ${item.title}\n      ${item.artist}", 14f, currentText) { playTrack(indexed.index) },
                LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(7) })
        }
    }

    private fun showCollection() {
        val page = pageColumn()
        page.addView(label(activePlaylistName ?: "Lagu", 29f, currentText, true))
        if (activePlaylistName != null) {
            addGap(page, 5)
            page.addView(actionText("‹  Semua lagu", 13f) { activePlaylistName = null; showCollection() }, LinearLayout.LayoutParams(-2, dp(38)))
        }
        addGap(page, 16)
        val search = EditText(this).apply {
            hint = "⌕  Telusuri koleksimu"
            setHintTextColor(currentMuted)
            setTextColor(currentText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(currentPanel, 28)
            setText(searchQuery)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchQuery = s?.toString().orEmpty()
                    rebuildTrackRows(rowsContainer)
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(54)))
        addGap(page, 10)
        page.addView(actionText("⤨   Acak", 16f) {
            val queue = playbackQueueIndices()
            if (queue.isNotEmpty()) playTrack(queue.random()) else if (tracks.isEmpty()) pickAudioFiles()
            else Toast.makeText(this, "Playlist ini belum memiliki lagu.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(55)))
        addGap(page, 18)
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val visibleCount = if (activePlaylistName == null) tracks.size else playlists.find { it.name == activePlaylistName }?.trackUris?.size ?: 0
        toolbar.addView(label("$visibleCount lagu", 14f, currentMuted, true), LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(actionText("＋ Playlist", 13f) { showCreatePlaylistDialog() })
        toolbar.addView(actionText("＋ Audio", 13f) { pickAudioFiles() }.apply { setPadding(dp(8), dp(10), dp(8), dp(10)) })
        page.addView(toolbar)
        if (activePlaylistName == null && playlists.isNotEmpty()) {
            addGap(page, 16)
            page.addView(label("Playlist", 18f, currentText, true))
            addGap(page, 6)
            playlists.forEach { playlist ->
                page.addView(actionText("♫   ${playlist.name}\n      ${playlist.trackUris.size} tracks   ›", 14f, currentText) {
                    activePlaylistName = playlist.name
                    searchQuery = ""
                    showCollection()
                }, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(7) })
            }
        }
        addGap(page, 12)
        page.addView(label(if (activePlaylistName == null) "Semua lagu" else "Isi playlist", 17f, currentText, true))
        rowsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(rowsContainer, LinearLayout.LayoutParams(-1, -2))
        rebuildTrackRows(rowsContainer)
        val playlistHasTracks = activePlaylistName?.let { name -> playlists.find { it.name == name }?.trackUris?.isNotEmpty() } ?: tracks.isNotEmpty()
        if (!playlistHasTracks) {
            addGap(page, 16)
            page.addView(label(if (activePlaylistName == null) "Koleksimu masih kosong. Tambahkan file audio dari penyimpanan perangkat." else "Playlist ini belum memiliki lagu. Kembali ke Semua lagu dan tahan sebuah lagu untuk menambahkannya.", 13f, currentMuted))
        }
        render("collection", scroll(page))
    }

    private lateinit var rowsContainer: LinearLayout

    private fun rebuildTrackRows(container: LinearLayout) {
        if (!::rowsContainer.isInitialized) return
        container.removeAllViews()
        val activeUris = activePlaylistName?.let { name -> playlists.find { it.name == name }?.trackUris?.toSet() }
        val filtered = tracks.withIndex().filter { indexed ->
            val belongs = activeUris == null || indexed.value.uri.toString() in activeUris
            val q = searchQuery.trim().lowercase(Locale.ROOT)
            belongs && (q.isEmpty() || indexed.value.title.lowercase(Locale.ROOT).contains(q) || indexed.value.artist.lowercase(Locale.ROOT).contains(q))
        }
        filtered.forEach { indexed ->
            val index = indexed.index
            val item = indexed.value
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener { playTrack(index) }
                setOnLongClickListener {
                    showAddTrackToPlaylistDialog(index)
                    true
                }
            }
            val cover = TextView(this).apply {
                text = "♫"
                textSize = 25f
                setTextColor(currentText)
                gravity = Gravity.CENTER
                background = rounded(currentPanel, 13)
            }
            row.addView(cover, LinearLayout.LayoutParams(dp(66), dp(66)))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(5), 0) }
            details.addView(label(item.title, 15f, currentText, true, 1))
            details.addView(label(item.artist, 12f, currentMuted, false, 1))
            details.addView(label(item.mime.ifBlank { "Audio lokal" }, 10f, currentAccent, true, 1))
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionText(if (index == currentIndex && isPlaying()) "Ⅱ" else "▶", 18f) { playTrack(index) }, LinearLayout.LayoutParams(dp(48), dp(44)))
            container.addView(row, LinearLayout.LayoutParams(-1, -2))
            val divider = View(this).apply { setBackgroundColor(if (themeName == "light") 0x22000000 else 0x33FFFFFF) }
            container.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun showPlayer() {
        val item = currentTrackOrNull()
        if (item == null) {
            Toast.makeText(this, "Pilih lagu terlebih dahulu.", Toast.LENGTH_SHORT).show()
            showCollection()
            return
        }
        val artworkBytes = getArtwork(item.uri)
        val useBlurBackdrop = artworkMode == "blur" && artworkBytes != null
        val playerHost = FrameLayout(this).apply { setBackgroundColor(currentBg) }
        if (useBlurBackdrop) {
            val backdrop = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(decodeArtwork(artworkBytes!!))
                alpha = 0.55f
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    setRenderEffect(android.graphics.RenderEffect.createBlurEffect(32f, 32f, android.graphics.Shader.TileMode.CLAMP))
                }
            }
            playerHost.addView(backdrop, FrameLayout.LayoutParams(-1, -1))
            playerHost.addView(View(this).apply {
                setBackgroundColor(if (themeName == "light") 0xAAEEEEEE.toInt() else 0x99000000.toInt())
            }, FrameLayout.LayoutParams(-1, -1))
        }
        val page = pageColumn().apply { if (useBlurBackdrop) setBackgroundColor(Color.TRANSPARENT) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(actionText("‹", 24f) { showCollection() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        header.addView(label("NOW PLAYING", 13f, currentMuted, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        header.addView(actionText("⋯", 22f) { showSettings() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        page.addView(header)
        addGap(page, 16)

        val artFrame = FrameLayout(this).apply { background = rounded(if (themeName == "light") 0xFFE0E0E0.toInt() else 0xFF252525.toInt(), 20) }
        val art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val decodedArtwork = artworkBytes?.let { decodeArtwork(it) }
            if (decodedArtwork != null) setImageBitmap(decodedArtwork)
            else setImageResource(android.R.drawable.ic_media_play)
            if (bytes == null) setColorFilter(currentAccent)
            else if (artworkMode == "grayscale") {
                val matrix = android.graphics.ColorMatrix().apply { setSaturation(0f) }
                colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
            }
        }
        artFrame.addView(art, FrameLayout.LayoutParams(-1, -1))
        val artSize = (resources.displayMetrics.widthPixels - dp(64)).coerceAtMost(dp(350))
        page.addView(artFrame, LinearLayout.LayoutParams(artSize, artSize).apply { gravity = Gravity.CENTER_HORIZONTAL })
        addGap(page, 20)

        val songTitle = label(item.title, 22f, currentText, true, 2)
        val artist = label(item.artist, 17f, currentMuted, true, 1)
        page.addView(songTitle)
        page.addView(artist)
        addGap(page, 18)

        playerProgress = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(currentAccent)
            thumbTintList = android.content.res.ColorStateList.valueOf(currentAccent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && playerPrepared) try { mediaPlayer?.seekTo(progress) } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(playerProgress, LinearLayout.LayoutParams(-1, dp(32)))
        playerTime = label("00:00   ·   00:00", 12f, currentMuted, true)
        playerTime?.gravity = Gravity.CENTER
        page.addView(playerTime)
        playerFormat = label("${item.mime}  ·  file lokal", 11f, currentMuted)
        playerFormat?.gravity = Gravity.CENTER
        page.addView(playerFormat)
        addGap(page, 22)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(actionText("|◀", 22f) { previousTrack() }, LinearLayout.LayoutParams(dp(68), dp(58)))
        controls.addView(View(this), LinearLayout.LayoutParams(dp(14), 1))
        controls.addView(actionText(if (isPlaying()) "Ⅱ" else "▶", 28f) { togglePlayback(); showPlayer() }, LinearLayout.LayoutParams(dp(82), dp(64)))
        controls.addView(View(this), LinearLayout.LayoutParams(dp(14), 1))
        controls.addView(actionText("▶|", 22f) { nextTrack() }, LinearLayout.LayoutParams(dp(68), dp(58)))
        page.addView(controls)
        addGap(page, 20)

        page.addView(label("Volume", 12f, currentMuted, true))
        val volume = SeekBar(this).apply {
            max = 100
            progress = 80
            progressTintList = android.content.res.ColorStateList.valueOf(currentAccent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress.coerceIn(0, 100) / 100f
                    try { mediaPlayer?.setVolume(v, v) } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(volume)
        addGap(page, 18)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionText("Lirik", 14f) { showLyrics() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(actionText("Antrean", 14f) { showQueue() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(actionText("Audio Lab", 14f) { showAudioLab() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        page.addView(actions)
        playerHost.addView(scroll(page), FrameLayout.LayoutParams(-1, -1))
        render("player", playerHost)
        updateProgressDisplay()
    }

    private fun showLyrics() {
        val page = pageColumn()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(actionText("‹", 24f) { showPlayer() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        header.addView(label("LIRIK", 23f, currentText, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        header.addView(actionText("＋ LRC", 13f) { pickLrcFile() })
        page.addView(header)
        addGap(page, 12)
        page.addView(actionText("Deteksi embedded lyrics", 14f) { reloadEmbeddedLyrics() }, LinearLayout.LayoutParams(-1, dp(48)))
        addGap(page, 16)
        val title = currentTrackOrNull()?.title ?: "Tidak ada lagu"
        page.addView(label(title, 16f, currentMuted, true))
        addGap(page, 12)
        lyricsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(8), dp(16), dp(8), dp(16)) }
        page.addView(lyricsContainer, LinearLayout.LayoutParams(-1, -2))
        lyricsScrollView = scroll(page)
        render("lyrics", lyricsScrollView!!)
        rebuildLyricsView()
    }

    private lateinit var lyricsContainer: LinearLayout

    private fun rebuildLyricsView() {
        if (!::lyricsContainer.isInitialized) return
        lyricsContainer.removeAllViews()
        lyricLineViews.clear()
        lastActiveLyricIndex = -2
        if (currentLyrics.isEmpty()) {
            lyricsContainer.addView(label("Lirik belum tersedia.\n\nPilih file .LRC atau coba deteksi lirik yang tertanam pada file audio.", 14f, currentMuted).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(35), dp(12), dp(35))
            })
            return
        }
        currentLyrics.forEach { line ->
            val view = label(line.text.ifBlank { "♪" }, 17f, currentMuted, false).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(9), dp(10), dp(9))
            }
            lyricsContainer.addView(view, LinearLayout.LayoutParams(-1, -2))
            lyricLineViews.add(view)
        }
        updateActiveLyric(0L)
    }

    private fun updateActiveLyric(positionMs: Long) {
        if (currentLyrics.isEmpty() || lyricLineViews.size != currentLyrics.size) return
        var active = -1
        val hasTiming = currentLyrics.any { it.timeMs > 0L }
        if (hasTiming) currentLyrics.forEachIndexed { index, line -> if (line.timeMs <= positionMs) active = index }
        lyricLineViews.forEachIndexed { index, view ->
            val selected = index == active
            view.setTextColor(if (selected) currentAccent else currentMuted)
            view.textSize = if (selected) 20f else 16f
            view.typeface = if (selected) {
                when (fontStyle) {
                    "serif" -> Typeface.create("serif", Typeface.BOLD)
                    "sans" -> Typeface.create("sans-serif", Typeface.BOLD)
                    else -> appFont ?: Typeface.DEFAULT_BOLD
                }
            } else Typeface.DEFAULT
        }
        if (active >= 0 && active != lastActiveLyricIndex) {
            lastActiveLyricIndex = active
            val selectedView = lyricLineViews.getOrNull(active)
            selectedView?.let { activeView ->
                activeView.post {
                    val targetY = (lyricsContainer.top + activeView.top - (lyricsScrollView?.height ?: 0) / 2).coerceAtLeast(0)
                    lyricsScrollView?.smoothScrollTo(0, targetY)
                }
            }
        }
    }

    private fun reloadEmbeddedLyrics() {
        val item = currentTrackOrNull() ?: return
        Toast.makeText(this, "Membaca metadata lirik…", Toast.LENGTH_SHORT).show()
        thread(name = "bds-lyrics-reader") {
            val text = LyricsRepository.readEmbeddedLyrics(this, item.uri)
            val parsed = text?.let { LyricsRepository.parseLrc(it) }.orEmpty()
            runOnUiThread {
                currentLyrics = parsed
                if (parsed.isEmpty()) Toast.makeText(this, "Embedded lyrics tidak ditemukan pada format yang didukung.", Toast.LENGTH_LONG).show()
                rebuildLyricsView()
            }
        }
    }

    private fun showQueue() {
        val page = pageColumn()
        page.addView(label("Antrean", 26f, currentText, true))
        addGap(page, 14)
        tracks.forEachIndexed { index, item ->
            page.addView(actionText("${index + 1}.  ${item.title}\n      ${item.artist}", 14f, if (index == currentIndex) currentAccent else currentText) { playTrack(index) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        render("queue", scroll(page))
    }

    private fun showAudioLab() {
        val page = pageColumn()
        page.addView(label("Audio Lab", 28f, currentText, true))
        page.addView(label("Diagnostik native C++ dan pengujian codec.", 13f, currentMuted))
        addGap(page, 20)
        page.addView(label("Native Engine", 17f, currentText, true))
        addGap(page, 8)
        val info = label(NativeBds.engineInfoSafe(), 13f, currentMuted).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(currentPanel, 14) }
        page.addView(info, LinearLayout.LayoutParams(-1, -2))
        addGap(page, 14)
        page.addView(actionText("Jalankan Native Self-Test", 15f) {
            info.text = if (NativeBds.available) NativeBds.selfTestSafe() else NativeBds.selfTestSafe()
        }, LinearLayout.LayoutParams(-1, dp(52)))
        addGap(page, 18)
        page.addView(label("Status implementasi codec", 17f, currentText, true))
        addGap(page, 8)
        val status = label(NativeBds.codecStatusSafe(), 13f, currentMuted).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(currentPanel, 14) }
        page.addView(status, LinearLayout.LayoutParams(-1, -2))
        addGap(page, 18)
        page.addView(label("Parameter proyek", 17f, currentText, true))
        page.addView(label("PCM target: 48 kHz · OSR target: 16× · Core: C++20\nPrioritas: kualitas dan pengujian terukur", 13f, currentMuted))
        render("lab", scroll(page))
    }

    private fun showSettings() {
        val page = pageColumn()
        page.addView(label("Settings", 28f, currentText, true))
        page.addView(label("Personalisasi tampilan BDS Studio", 13f, currentMuted))
        addGap(page, 18)
        page.addView(label("Tema", 17f, currentText, true))
        listOf("midnight" to "Midnight", "monochrome" to "Monochrome", "light" to "Light").forEach { (value, title) ->
            page.addView(actionText((if (themeName == value) "✓  " else "   ") + title, 14f, if (themeName == value) currentAccent else currentText) {
                preferences.edit().putString("theme", value).apply()
                applySavedTheme()
                buildShell()
                showSettings()
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        }
        addGap(page, 18)
        page.addView(label("Warna aksen", 17f, currentText, true))
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("#F04444", "#4A90E2", "#9B59B6", "#2ECC71", "#E5B84B", "#FFFFFF").forEach { colorString ->
            val color = Color.parseColor(colorString)
            val swatch = View(this).apply {
                background = rounded(color, 50)
                setOnClickListener {
                    preferences.edit().putString("accent", colorString).apply()
                    applySavedTheme()
                    buildShell()
                    showSettings()
                }
            }
            swatches.addView(swatch, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(9); topMargin = dp(10) })
        }
        page.addView(swatches)
        addGap(page, 20)
        page.addView(label("Tipografi", 17f, currentText, true))
        page.addView(label("Pilih gaya untuk judul dan elemen utama.", 12f, currentMuted))
        listOf("hywenhei" to "HYWenHei 85W (default)", "serif" to "Serif", "sans" to "Sans-serif").forEach { (value, title) ->
            page.addView(actionText((if (fontStyle == value) "✓  " else "   ") + title, 13f, if (fontStyle == value) currentAccent else currentText) {
                preferences.edit().putString("font_style", value).apply()
                fontStyle = value
                showSettings()
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(5) })
        }
        addGap(page, 16)
        page.addView(label("Artwork player", 17f, currentText, true))
        listOf("original" to "Original", "grayscale" to "Grayscale", "blur" to "Soft blur background").forEach { (value, title) ->
            page.addView(actionText((if (artworkMode == value) "✓  " else "   ") + title, 13f, if (artworkMode == value) currentAccent else currentText) {
                preferences.edit().putString("artwork_mode", value).apply()
                artworkMode = value
                showSettings()
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(5) })
        }
        addGap(page, 12)
        page.addView(label("Informasi aplikasi", 17f, currentText, true))
        page.addView(label("BDS Studio 7.0.0\nNative C++20 · Android NDK · JNI\nLocal-first: file musik dibaca melalui pemilih file Android.", 13f, currentMuted))
        addGap(page, 14)
        page.addView(actionText("Reset tampilan ke default", 14f) {
            preferences.edit()
                .putString("theme", "midnight")
                .putString("accent", "#F04444")
                .putString("font_style", "hywenhei")
                .putString("artwork_mode", "original")
                .apply()
            applySavedTheme()
            buildShell()
            showSettings()
        }, LinearLayout.LayoutParams(-1, dp(48)))
        render("settings", scroll(page))
    }

    private fun pickAudioFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_AUDIO)
    }

    private fun pickLrcFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_LRC)
    }

    private fun pickBdsFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_BDS)
    }

    @Deprecated("Uses the Storage Access Framework result for compatibility with the starter project.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQUEST_AUDIO -> {
                val selected = mutableListOf<Uri>()
                data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected += clip.getItemAt(i).uri }
                data.data?.let { if (selected.isEmpty()) selected += it }
                selected.forEach { uri ->
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                    val item = readTrack(uri)
                    if (tracks.none { it.uri == uri }) tracks += item
                }
                saveLibraryUris()
                searchQuery = ""
                showCollection()
                Toast.makeText(this, "${selected.size} file ditambahkan.", Toast.LENGTH_SHORT).show()
            }
            REQUEST_LRC -> {
                val uri = data.data ?: return
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                thread(name = "bds-lrc-reader") {
                    val text = LyricsRepository.readLrc(this, uri).orEmpty()
                    val parsed = LyricsRepository.parseLrc(text)
                    runOnUiThread {
                        currentLyrics = parsed
                        showLyrics()
                        if (parsed.isEmpty()) Toast.makeText(this, "File LRC kosong atau format timestamp tidak dikenali.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            REQUEST_BDS -> {
                val uri = data.data ?: return
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (bdsFiles.none { it == uri }) bdsFiles += uri
                showRepo()
                Toast.makeText(this, "File ditambahkan ke Repo. Parser BDS lengkap masih dalam pengembangan.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun readTrack(uri: Uri): AudioTrackItem {
        var title = "Audio tanpa judul"
        var artist = "Unknown Artist"
        var mime = contentResolver.getType(uri) ?: "audio/*"
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: displayName(uri) ?: title
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: artist
            mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: mime
            retriever.release()
        } catch (_: Exception) {
            title = displayName(uri) ?: title
        }
        return AudioTrackItem(uri, title, artist, mime)
    }

    private fun displayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun decodeArtwork(bytes: ByteArray): android.graphics.Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            val targetPixels = 1100
            while (bounds.outWidth / sample > targetPixels || bounds.outHeight / sample > targetPixels) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        } catch (_: Exception) { null }
    }

    private fun getArtwork(uri: Uri): ByteArray? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val picture = retriever.embeddedPicture
            retriever.release()
            picture
        } catch (_: Exception) { null }
    }

    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        currentIndex = index
        playerPrepared = false
        currentLyrics = emptyList()
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        val item = tracks[index]
        Toast.makeText(this, "Memuat ${item.title}", Toast.LENGTH_SHORT).show()
        loadEmbeddedLyrics(item.uri)
        try {
            val player = MediaPlayer()
            mediaPlayer = player
            player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setOnPreparedListener { ready ->
                playerPrepared = true
                ready.start()
                showPlayer()
                updateProgressDisplay()
                refreshBottomAreas()
            }
            player.setOnCompletionListener { nextTrack() }
            player.setOnErrorListener { _, what, extra ->
                playerPrepared = false
                Toast.makeText(this, "Audio tidak dapat diputar (error $what/$extra).", Toast.LENGTH_LONG).show()
                true
            }
            player.setDataSource(this, item.uri)
            player.prepareAsync()
        } catch (e: Exception) {
            playerPrepared = false
            Toast.makeText(this, "Gagal membuka audio: ${e.message ?: "format tidak didukung"}", Toast.LENGTH_LONG).show()
        }
        rebuildTrackRowsIfVisible()
    }

    private fun loadEmbeddedLyrics(uri: Uri) {
        thread(name = "bds-embedded-lyrics") {
            val text = LyricsRepository.readEmbeddedLyrics(this, uri)
            val parsed = text?.let { LyricsRepository.parseLrc(it) }.orEmpty()
            runOnUiThread {
                if (currentTrackOrNull()?.uri == uri && parsed.isNotEmpty()) {
                    currentLyrics = parsed
                    if (currentPage == "lyrics") rebuildLyricsView()
                }
            }
        }
    }

    private fun togglePlayback() {
        val player = mediaPlayer
        if (player == null || !playerPrepared) {
            if (currentIndex >= 0) playTrack(currentIndex) else pickAudioFiles()
            return
        }
        try {
            if (player.isPlaying) player.pause() else player.start()
        } catch (_: IllegalStateException) {}
        if (currentPage == "player") showPlayer() else refreshBottomAreas()
    }

    private fun playbackQueueIndices(): List<Int> {
        val uris = activePlaylistName?.let { name -> playlists.find { it.name == name }?.trackUris?.toSet() }
        return tracks.indices.filter { index -> uris == null || tracks[index].uri.toString() in uris }
    }

    private fun previousTrack() {
        val queue = playbackQueueIndices()
        if (queue.isEmpty()) return
        val position = queue.indexOf(currentIndex).let { if (it < 0) 0 else it }
        playTrack(queue[if (position <= 0) queue.lastIndex else position - 1])
    }

    private fun nextTrack() {
        val queue = playbackQueueIndices()
        if (queue.isEmpty()) return
        val position = queue.indexOf(currentIndex).let { if (it < 0) -1 else it }
        playTrack(queue[if (position >= queue.lastIndex) 0 else position + 1])
    }

    private fun isPlaying(): Boolean = try { mediaPlayer?.isPlaying == true } catch (_: Exception) { false }

    private fun currentTrackOrNull(): AudioTrackItem? = tracks.getOrNull(currentIndex)

    private fun updateProgressDisplay() {
        if (!playerPrepared) return
        try {
            val duration = mediaPlayer?.duration ?: 0
            val position = mediaPlayer?.currentPosition ?: 0
            playerProgress?.max = duration.coerceAtLeast(1)
            playerProgress?.progress = position
            playerTime?.text = "${formatTime(position)}   ·   -${formatTime((duration - position).coerceAtLeast(0))}"
        } catch (_: Exception) {}
    }

    private fun rebuildTrackRowsIfVisible() {
        if (currentPage == "collection" && ::rowsContainer.isInitialized) rebuildTrackRows(rowsContainer)
    }

    private fun formatTime(milliseconds: Int): String {
        val seconds = (milliseconds / 1000).coerceAtLeast(0)
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onBackPressed() {
        when (currentPage) {
            "lyrics", "queue" -> showPlayer()
            "player" -> showCollection()
            "lab", "settings", "home" -> showCollection()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        progressHandler.removeCallbacks(progressRunnable)
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_AUDIO = 1001
        private const val REQUEST_LRC = 1002
        private const val REQUEST_BDS = 1003
    }
}
