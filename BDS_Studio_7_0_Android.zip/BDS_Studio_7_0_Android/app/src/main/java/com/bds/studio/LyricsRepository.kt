package com.bds.studio

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.util.Locale

data class LyricLine(val timeMs: Long, val text: String)

object LyricsRepository {

    fun parseLrc(content: String): List<LyricLine> {
        val timestampRegex = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val timed = mutableListOf<LyricLine>()
        content.lineSequence().forEach { raw ->
            val line = raw.trimEnd('\r')
            val matches = timestampRegex.findAll(line).toList()
            if (matches.isNotEmpty()) {
                val lyricText = line.substring(matches.last().range.last + 1).trim()
                matches.forEach { match ->
                    val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                    val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                    val fractionRaw = match.groupValues.getOrNull(3).orEmpty()
                    val millis = when (fractionRaw.length) {
                        1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                        2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                        else -> fractionRaw.toLongOrNull() ?: 0L
                    }
                    timed += LyricLine((minutes * 60L + seconds) * 1000L + millis, lyricText)
                }
            }
        }
        if (timed.isNotEmpty()) return timed.sortedBy { it.timeMs }
        return content.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("[") }
            .map { LyricLine(0L, it) }
            .toList()
    }

    fun readLrc(context: Context, uri: Uri): String? = try {
        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
    } catch (_: Exception) {
        null
    }

    /** Reads common embedded lyric forms: ID3v2 USLT (MP3) and FLAC Vorbis comments. */
    fun readEmbeddedLyrics(context: Context, uri: Uri): String? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (total < MAX_METADATA_BYTES) {
                    val count = input.read(buffer, 0, minOf(buffer.size, MAX_METADATA_BYTES - total))
                    if (count <= 0) break
                    output.write(buffer, 0, count)
                    total += count
                }
                output.toByteArray()
            } ?: return null
            readId3Uslt(bytes) ?: readFlacVorbisLyrics(bytes)
        } catch (_: Exception) {
            null
        }
    }

    private fun readId3Uslt(data: ByteArray): String? {
        if (data.size < 10 || data[0] != 'I'.code.toByte() || data[1] != 'D'.code.toByte() || data[2] != '3'.code.toByte()) return null
        val version = data[3].toInt() and 0xff
        if (version !in 3..4) return null
        val tagSize = synchsafe(data, 6)
        var offset = 10
        val end = minOf(data.size, 10 + tagSize)
        while (offset + 10 <= end) {
            val id = String(data, offset, 4, StandardCharsets.ISO_8859_1)
            if (id.all { it == '\u0000' }) break
            val frameSize = if (version == 4) synchsafe(data, offset + 4) else bigEndianInt(data, offset + 4)
            offset += 10
            if (frameSize <= 0 || offset + frameSize > end) break
            if (id == "USLT") {
                val frame = data.copyOfRange(offset, offset + frameSize)
                return decodeUnsynchronizedLyrics(frame)
            }
            offset += frameSize
        }
        return null
    }

    private fun decodeUnsynchronizedLyrics(frame: ByteArray): String? {
        if (frame.size < 5) return null
        val encoding = frame[0].toInt() and 0xff
        val start = 4 // text encoding byte + three-byte language
        val terminatorLength = if (encoding == 1 || encoding == 2) 2 else 1
        var cursor = start
        while (cursor + terminatorLength <= frame.size) {
            val isEnd = if (terminatorLength == 1) {
                frame[cursor] == 0.toByte()
            } else {
                frame[cursor] == 0.toByte() && frame[cursor + 1] == 0.toByte()
            }
            if (isEnd) break
            cursor += terminatorLength
        }
        cursor = minOf(frame.size, cursor + terminatorLength)
        if (cursor >= frame.size) return null
        val charset = when (encoding) {
            0 -> StandardCharsets.ISO_8859_1
            1 -> Charsets.UTF_16
            2 -> StandardCharsets.UTF_16BE
            3 -> StandardCharsets.UTF_8
            else -> StandardCharsets.UTF_8
        }
        return String(frame, cursor, frame.size - cursor, charset).trim('\u0000', '\uFEFF', '\n', '\r', ' ').takeIf { it.isNotBlank() }
    }

    private fun readFlacVorbisLyrics(data: ByteArray): String? {
        if (data.size < 8 || String(data, 0, 4, StandardCharsets.ISO_8859_1) != "fLaC") return null
        var offset = 4
        while (offset + 4 <= data.size) {
            val header = data[offset].toInt() and 0xff
            val type = header and 0x7f
            val length = ((data[offset + 1].toInt() and 0xff) shl 16) or
                ((data[offset + 2].toInt() and 0xff) shl 8) or
                (data[offset + 3].toInt() and 0xff)
            offset += 4
            if (length < 0 || offset + length > data.size) break
            if (type == 4) {
                val blockEnd = offset + length
                var p = offset
                if (p + 4 > blockEnd) return null
                val vendorLength = littleEndianInt(data, p)
                p += 4 + vendorLength
                if (p + 4 > blockEnd) return null
                val count = littleEndianInt(data, p)
                p += 4
                repeat(count.coerceIn(0, 100_000)) {
                    if (p + 4 > blockEnd) return null
                    val commentLength = littleEndianInt(data, p)
                    p += 4
                    if (commentLength < 0 || p + commentLength > blockEnd) return null
                    val comment = String(data, p, commentLength, StandardCharsets.UTF_8)
                    p += commentLength
                    val equals = comment.indexOf('=')
                    if (equals > 0) {
                        val key = comment.substring(0, equals).uppercase(Locale.ROOT)
                        if (key == "LYRICS" || key == "UNSYNCEDLYRICS") {
                            return comment.substring(equals + 1).trim().takeIf { it.isNotBlank() }
                        }
                    }
                }
            }
            offset += length
            if ((header and 0x80) != 0) break
        }
        return null
    }

    private fun synchsafe(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0x7f) shl 21) or
            ((data[offset + 1].toInt() and 0x7f) shl 14) or
            ((data[offset + 2].toInt() and 0x7f) shl 7) or
            (data[offset + 3].toInt() and 0x7f)
    }

    private fun bigEndianInt(data: ByteArray, offset: Int): Int {
        return ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).int
    }

    private fun littleEndianInt(data: ByteArray, offset: Int): Int {
        return ByteBuffer.wrap(data, offset, 4).order(ByteOrder.LITTLE_ENDIAN).int
    }

    private const val MAX_METADATA_BYTES = 16 * 1024 * 1024
}
