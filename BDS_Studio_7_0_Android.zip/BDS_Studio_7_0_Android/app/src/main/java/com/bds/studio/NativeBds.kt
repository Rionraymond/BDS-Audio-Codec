package com.bds.studio

/** JNI entry points for the experimental BDS native core. */
object NativeBds {
    val available: Boolean

    init {
        available = try {
            System.loadLibrary("bds_native")
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    external fun nativeEngineInfo(): String
    external fun nativeRunSelfTest(): String
    external fun nativeCodecStatus(): String

    fun engineInfoSafe(): String = if (available) nativeEngineInfo() else "Native library belum berhasil dimuat."
    fun selfTestSafe(): String = if (available) nativeRunSelfTest() else "Self-test tidak dapat dijalankan: native library tidak tersedia."
    fun codecStatusSafe(): String = if (available) nativeCodecStatus() else "BDS native core tidak tersedia."
}
