#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace bds {

// Experimental symbol packing primitive. Symbol mapping: -1 -> 0, 0 -> 1, +1 -> 2.
// Five ternary symbols are packed into one byte (3^5 = 243 valid values).
std::vector<std::uint8_t> pack_radix3(const std::vector<std::int8_t>& symbols);
bool unpack_radix3(const std::vector<std::uint8_t>& bytes,
                   std::size_t symbol_count,
                   std::vector<std::int8_t>& output);

std::string engine_info();
std::string run_self_test();
std::string codec_status();

} // namespace bds
