#include "bds_core.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdexcept>

namespace bds {
namespace {
constexpr int kOsr = 16;
constexpr int kSampleRate = 48'000;
constexpr int kInternalRate = kSampleRate * kOsr;
constexpr std::uint8_t kRadix3InvalidStart = 243;

class ExperimentalSecondOrderModulator {
public:
    std::int8_t process(float sample) noexcept {
        // This is the experimental error-feedback quantizer retained for research.
        // It is not yet a verified/stable production modulator.
        const double value = static_cast<double>(sample) + 2.0 * error_1_ - error_2_;
        const std::int8_t symbol = value > 0.5 ? 1 : (value < -0.5 ? -1 : 0);
        const double error = value - static_cast<double>(symbol);
        error_2_ = error_1_;
        error_1_ = error;
        return symbol;
    }

    bool finite() const noexcept {
        return std::isfinite(error_1_) && std::isfinite(error_2_);
    }

private:
    double error_1_ = 0.0;
    double error_2_ = 0.0;
};
} // namespace

std::vector<std::uint8_t> pack_radix3(const std::vector<std::int8_t>& symbols) {
    std::vector<std::uint8_t> packed;
    packed.reserve((symbols.size() + 4U) / 5U);

    for (std::size_t i = 0; i < symbols.size(); i += 5U) {
        unsigned value = 0U;
        unsigned factor = 1U;
        for (std::size_t j = 0; j < 5U; ++j) {
            // Missing tail values are padded with symbol 0 (ternary digit 1).
            const std::int8_t symbol = (i + j < symbols.size()) ? symbols[i + j] : 0;
            if (symbol < -1 || symbol > 1) {
                throw std::invalid_argument("BDS symbol must be -1, 0, or +1");
            }
            const unsigned digit = static_cast<unsigned>(symbol + 1);
            value += digit * factor;
            factor *= 3U;
        }
        packed.push_back(static_cast<std::uint8_t>(value));
    }
    return packed;
}

bool unpack_radix3(const std::vector<std::uint8_t>& bytes,
                   const std::size_t symbol_count,
                   std::vector<std::int8_t>& output) {
    const std::size_t required = (symbol_count + 4U) / 5U;
    if (bytes.size() != required) return false;

    output.clear();
    output.reserve(symbol_count);
    for (const std::uint8_t byte : bytes) {
        if (byte >= kRadix3InvalidStart) return false;
        unsigned value = byte;
        for (int j = 0; j < 5; ++j) {
            const unsigned digit = value % 3U;
            value /= 3U;
            if (output.size() < symbol_count) {
                output.push_back(static_cast<std::int8_t>(static_cast<int>(digit) - 1));
            }
        }
    }
    return output.size() == symbol_count;
}

std::string engine_info() {
    std::ostringstream out;
    out << "BDS Native Core 7.0\n"
        << "C++ standard: C++20\n"
        << "PCM target: " << kSampleRate << " Hz (stereo pipeline planned)\n"
        << "Configured OSR: " << kOsr << "x\n"
        << "Internal rate target: " << kInternalRate << " Hz\n"
        << "Radix-3 symbols: -1 / 0 / +1\n"
        << "State: experimental DSP primitives";
    return out.str();
}

std::string run_self_test() {
    std::ostringstream report;
    bool pack_ok = true;
    bool invalid_guard_ok = true;
    bool modulator_finite = true;
    std::size_t symbol_count = 0;

    try {
        // Exhaustively round-trip all 243 possible five-trit values.
        std::vector<std::int8_t> all_patterns;
        all_patterns.reserve(243U * 5U);
        for (unsigned code = 0; code < 243U; ++code) {
            unsigned value = code;
            for (int j = 0; j < 5; ++j) {
                const unsigned digit = value % 3U;
                value /= 3U;
                all_patterns.push_back(static_cast<std::int8_t>(static_cast<int>(digit) - 1));
            }
        }
        const auto packed = pack_radix3(all_patterns);
        std::vector<std::int8_t> decoded;
        pack_ok = unpack_radix3(packed, all_patterns.size(), decoded) && decoded == all_patterns;

        std::vector<std::int8_t> invalid_output;
        for (unsigned reserved = 243U; reserved <= 255U; ++reserved) {
            if (unpack_radix3({static_cast<std::uint8_t>(reserved)}, 5U, invalid_output)) {
                invalid_guard_ok = false;
                break;
            }
        }

        // Numerical smoke test of the experimental quantizer at the configured internal rate.
        // This does not test interpolation, reconstruction, THD+N, or audible codec quality.
        ExperimentalSecondOrderModulator modulator;
        constexpr std::size_t test_samples = static_cast<std::size_t>(kInternalRate / 2);
        for (std::size_t n = 0; n < test_samples; ++n) {
            const double t = static_cast<double>(n) / static_cast<double>(kInternalRate);
            const float sample = static_cast<float>(0.35 * std::sin(2.0 * 3.14159265358979323846 * 997.0 * t));
            const std::int8_t symbol = modulator.process(sample);
            if (symbol < -1 || symbol > 1 || !modulator.finite()) {
                modulator_finite = false;
                break;
            }
            ++symbol_count;
        }
    } catch (...) {
        pack_ok = false;
    }

    report << "BDS Native Self-Test\n"
           << "Radix-3 exhaustive round-trip: " << (pack_ok ? "PASS" : "FAIL") << "\n"
           << "Reserved byte rejection (243-255): " << (invalid_guard_ok ? "PASS" : "FAIL") << "\n"
           << "Experimental quantizer finite-state smoke test: " << (modulator_finite ? "PASS" : "FAIL") << "\n"
           << "Quantizer test symbols processed: " << symbol_count << "\n"
           << "\nImportant: this is a primitive-level test, not a full WAV-to-BDS codec or audio-quality certification.";
    return report.str();
}

std::string codec_status() {
    return "Implemented: Radix-3 pack/unpack primitive and experimental ternary quantizer.\n"
           "Not implemented yet: complete BDS file container, stereo WAV encoder/decoder, metadata, CRC, and production reconstruction filter.\n"
           "The OSR 16x value is configured for the next DSP integration milestone; this self-test does not prove end-to-end 16x conversion.";
}

} // namespace bds
