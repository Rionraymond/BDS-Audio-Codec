cmake_minimum_required(VERSION 3.22.1)
project(bds_native LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(bds_native SHARED
    bds_core.cpp
    bds_jni.cpp
)

target_compile_options(bds_native PRIVATE
    -Wall -Wextra -Wpedantic
    -O3
)

find_library(log-lib log)
target_link_libraries(bds_native ${log-lib})
