#include "bds_core.hpp"

#include <jni.h>
#include <string>

namespace {
jstring to_java_string(JNIEnv* env, const std::string& value) {
    return env->NewStringUTF(value.c_str());
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_bds_studio_NativeBds_nativeEngineInfo(JNIEnv* env, jobject /* thiz */) {
    return to_java_string(env, bds::engine_info());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_bds_studio_NativeBds_nativeRunSelfTest(JNIEnv* env, jobject /* thiz */) {
    return to_java_string(env, bds::run_self_test());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_bds_studio_NativeBds_nativeCodecStatus(JNIEnv* env, jobject /* thiz */) {
    return to_java_string(env, bds::codec_status());
}
