@echo off
setlocal
set VERSION=8.9
set BASE=%USERPROFILE%\.gradle\bds-wrapper\gradle-%VERSION%
set GRADLE=%BASE%\bin\gradle.bat
if exist "%GRADLE%" goto run
set ZIP=%TEMP%\bds-gradle-%VERSION%.zip
echo BDS Studio: Gradle %VERSION% belum tersedia; mengunduh distribusi resmi...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force -Path '%BASE%' | Out-Null; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'; Expand-Archive -Force -Path '%ZIP%' -DestinationPath '%USERPROFILE%\.gradle\bds-wrapper'"
if errorlevel 1 exit /b 1
:run
call "%GRADLE%" %*
exit /b %ERRORLEVEL%
