#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>
#include <span>

namespace bds {

enum class PcmFormat {
    PCM16,
    PCM24
};

struct PcmBuffer {
    std::vector<float> samples;
    std::uint32_t sample_rate = 48000;
    std::uint8_t channels = 2;
};

bool pcm16_to_float(
    std::span<const std::int16_t> input,
    std::vector<float>& output
);

bool pcm24_to_float(
    std::span<const std::uint8_t> input,
    std::vector<float>& output
);

bool decode_pcm(
    std::span<const std::uint8_t> input,
    PcmFormat format,
    std::vector<float>& output
);

}
