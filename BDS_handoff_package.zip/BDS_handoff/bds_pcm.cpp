#include "bds_pcm.hpp"

namespace bds {

bool pcm16_to_float(
    std::span<const std::int16_t> input,
    std::vector<float>& output
) {
    output.resize(input.size());

    constexpr float scale = 1.0f / 32768.0f;

    for (std::size_t i = 0; i < input.size(); ++i) {
        output[i] = static_cast<float>(input[i]) * scale;
    }

    return true;
}

bool pcm24_to_float(
    std::span<const std::uint8_t> input,
    std::vector<float>& output
) {
    if (input.size() % 3 != 0) {
        output.clear();
        return false;
    }

    const std::size_t count = input.size() / 3;
    output.resize(count);

    constexpr float scale = 1.0f / 8388608.0f;

    for (std::size_t i = 0; i < count; ++i) {
        const std::size_t p = i * 3;

        std::int32_t value =
            static_cast<std::int32_t>(input[p]) |
            (static_cast<std::int32_t>(input[p + 1]) << 8) |
            (static_cast<std::int32_t>(input[p + 2]) << 16);

        if (value & 0x800000) {
            value -= 0x1000000;
        }

        output[i] = static_cast<float>(value) * scale;
    }

    return true;
}

bool decode_pcm(
    std::span<const std::uint8_t> input,
    PcmFormat format,
    std::vector<float>& output
) {
    if (format == PcmFormat::PCM24) {
        return pcm24_to_float(input, output);
    }

    if (input.size() % 2 != 0) {
        output.clear();
        return false;
    }

    const std::size_t count = input.size() / 2;
    output.resize(count);

    constexpr float scale = 1.0f / 32768.0f;

    for (std::size_t i = 0; i < count; ++i) {
        const std::uint16_t raw =
            static_cast<std::uint16_t>(input[i * 2]) |
            (static_cast<std::uint16_t>(input[i * 2 + 1]) << 8);

        const std::int16_t value =
            static_cast<std::int16_t>(raw);

        output[i] = static_cast<float>(value) * scale;
    }

    return true;
}

}
