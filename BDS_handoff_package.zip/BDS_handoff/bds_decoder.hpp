#pragma once

#include "bds_core.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

namespace bds {

bool decode_bds_audio(
    std::span<const std::uint8_t> input,
    std::size_t symbol_count,
    std::vector<float>& output
);

}
