# BDS Audio Codec — Handoff Package

Paket ini berisi source code yang teks implementasinya tersedia dalam rekaman percakapan:
- `bds_pcm.hpp` dan `bds_pcm.cpp`: konversi PCM16/PCM24 ke float.
- `bds_decoder.hpp`: deklarasi antarmuka decoder.
- `CMakeLists.txt`: konfigurasi build gabungan yang pernah disusun.

## Penting: paket ini bukan salinan lengkap proyek

Source berikut disebut dalam riwayat pengembangan, tetapi isi lengkapnya tidak tersedia untuk dimasukkan secara akurat ke arsip ini:
- `bds_core.hpp`
- `bds_core.cpp`
- `bds_decoder.cpp`
- `bds_jni.cpp`
- `bds_pcm_test.cpp`
- `bds_decoder_test.cpp`
- source aplikasi Android/Kotlin/Java dan file proyek lainnya
- skrip Python BDS Audio Codec v5.0

Jangan menganggap file yang tidak disertakan sebagai implementasi kosong atau sudah selesai. Salin file asli dari repositori/source awal proyek ke direktori ini sebelum melakukan build. `CMakeLists.txt` merujuk pada beberapa file yang memang belum disertakan.

## Ringkasan spesifikasi yang tercatat

- Bahasa native: C++20
- Sample rate: 48.000 Hz
- OSR pada implementasi terakhir yang dibahas: 8x
- Internal rate: 384.000 Hz
- Kanal: stereo
- Input PCM: 16-bit dan 24-bit
- Simbol ternary: -1, 0, +1
- Packing: lima simbol ternary per byte (3^5 = 243)
- Decoder awal: FIR low-pass 255 tap dan decimation OSR 8x

## Status teknis

PCM conversion telah diuji berhasil menurut laporan pengembang. Decoder berhasil dikompilasi menurut laporan pengembang. Namun, decoder tersebut masih tahap awal dan keseluruhan encoder-decoder belum tervalidasi end-to-end. Self-test dasar bukan bukti kualitas audio produksi.

## Integrasi

1. Gabungkan file dalam arsip ini dengan source asli BDS.
2. Pastikan file yang dirujuk `CMakeLists.txt` tersedia.
3. Jalankan build dan seluruh test dari source asli.
4. Validasi format bitstream, sinkronisasi kanal, batas buffer, latensi, dan kualitas audio.
5. Dokumentasikan setiap perubahan sebelum membuat rilis komunitas.
